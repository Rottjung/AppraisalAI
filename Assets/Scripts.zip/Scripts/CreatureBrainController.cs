using System.Collections.Generic;
using UnityEngine;

public class CreatureBrainController : MonoBehaviour
{
    [SerializeField] private DecisionBrain brain;
    [SerializeField] private Controller controller;
    [SerializeField] private Sensors sensors;

    [Header("Signal Ids")]
    [SerializeField] private string hungerSignalId = "hunger";
    [SerializeField] private string energySignalId = "energy";

    [Header("Target Tags")]
    [SerializeField] private string foodTag = "Food";
    [SerializeField] private string enemyTag = "Enemy";
    [SerializeField] private LevelBounds levelBounds;
    [SerializeField] private LearningController learningController;
    [SerializeField] private LearningState learningState;

    [Header("Decision Timing")]
    [SerializeField] private float decisionInterval = 0.15f;

    [Header("Movement")]
    [SerializeField] private float moveStrength = 1f;

    [Header("Eating")]
    [SerializeField] private float eatDistance = 1.2f;
    [SerializeField] private float hungerRestore = 0.6f;
    [SerializeField] private float energyRestoreOnEat = 0.35f;

    [Header("Idle/Wander Reservoir")]
    [SerializeField] private float idleTime = 0f;
    [SerializeField] private float maxIdleTime = 2f;
    [SerializeField] private float idleChargePerSecond = 1f;
    [SerializeField] private float wanderDrainPerSecond = 1f;

    [Header("Base Energy By State")]
    [SerializeField] private float idleEnergyGainPerSecond = 0.08f;
    [SerializeField] private float wanderEnergyDrainPerSecond = 0.06f;
    [SerializeField] private float seekFoodEnergyDrainPerSecond = 0.03f;
    [SerializeField] private float fleeEnergyDrainPerSecond = 0.08f;

    [Header("Metabolic Stress Scaling")]
    [SerializeField] private float idleRecoveryStressPenalty = 0.5f;
    [SerializeField] private float wanderStressMultiplier = 1.0f;
    [SerializeField] private float seekStressMultiplier = 0.75f;
    [SerializeField] private float fleeStressMultiplier = 0.5f;

    [Header("Wander Execution Parameters")]
    [SerializeField] private float wanderDistance = 6f;
    [SerializeField] private float retargetInterval = 2f;
    [SerializeField] private float minTargetDistance = 2f;
    [SerializeField, Range(0f, 1f)] private float forwardBias = 0.6f;
    [SerializeField] private Transform wanderTransform;

    [Header("Wander Target Sampling")]
    [SerializeField] private bool chainFromPreviousTarget = true;
    [SerializeField, Range(0f, 1f)] private float previousTargetBias = 0.8f;
    [SerializeField] private float minDistanceFromCurrentWhenChained = 1.5f;

    [Header("Path & Proximity Inputs")]
    // Maximum distance used to normalise the wander target to enemy distance.  If the
    // actual distance exceeds this value, the normalised signal will be clamped to 1.
    [SerializeField] private float enemyPathCheckRadius = 1.2f;
    [SerializeField] private float wanderTargetEnemyDistanceMax = 10f;

    [Header("Debug")]
    [SerializeField] private bool logDecisions = false;
    [SerializeField] private bool drawWanderTarget = true;

    private float decisionTimer;
    private string currentPayload = "Idle";

    private float wanderRetargetTimer;
    private Vector3 wanderTarget = Vector3.zero;
    private bool hasWanderTarget;

    private bool wanderCommitted;
    private bool isDead;
    private bool wanderEpisodeActive;

    private Vector3 lastKnownEnemyPosition;
    private bool hasLastKnownEnemyPosition;

    private void Update()
    {
        if (sensors == null || controller == null)
        {
            return;
        }

        float dt = Time.deltaTime;

        if (isDead)
        {
            controller.Stop();
            return;
        }

        // Internal needs such as hunger/energy drift are now handled by Sensor modules
        UpdateInternalState(dt);
        CheckDeath();

        if (isDead)
        {
            controller.Stop();
            return;
        }

        decisionTimer -= dt;
        if (decisionTimer <= 0f)
        {
            decisionTimer += decisionInterval;
            EvaluateDecision();
        }

        ExecuteCurrentPayload(dt);
    }

    // The threat memory timer has been removed.  Sensors of type RecentAnyInRadius now
    // handle short‑term threat memory.  We still track the last known enemy
    // position separately so that wandering logic can detect enemies on the path.

    private void UpdateInternalState(float deltaTime)
    {
        float metabolicStress = GetMetabolicStress();

        switch (currentPayload)
        {
            case "Idle":
                {
                    idleTime += idleChargePerSecond * deltaTime;

                    float idleGain = idleEnergyGainPerSecond * (1f - idleRecoveryStressPenalty * metabolicStress);
                    idleGain = Mathf.Max(0f, idleGain);

                    // Add energy using the configured energy signal id
                    ModifyEnergy(idleGain * deltaTime);
                    break;
                }

            case "Wander":
                {
                    idleTime -= wanderDrainPerSecond * deltaTime;

                    float wanderDrain = wanderEnergyDrainPerSecond * (1f + wanderStressMultiplier * metabolicStress);
                    // Subtract energy
                    ModifyEnergy(-wanderDrain * deltaTime);
                    break;
                }

            case "SeekFood":
                {
                    float seekDrain = seekFoodEnergyDrainPerSecond * (1f + seekStressMultiplier * metabolicStress);
                    ModifyEnergy(-seekDrain * deltaTime);
                    break;
                }

            case "FleeEnemy":
                {
                    float fleeDrain = fleeEnergyDrainPerSecond * (1f + fleeStressMultiplier * metabolicStress);
                    ModifyEnergy(-fleeDrain * deltaTime);
                    break;
                }

            case "RepickTarget":
                break;
        }

        idleTime = Mathf.Clamp(idleTime, 0f, maxIdleTime);

        UpdateBrainRuntimeInputs();

        if (wanderCommitted && idleTime <= 0f)
        {
            wanderCommitted = false;
        }
    }

    private void UpdateBrainRuntimeInputs()
    {
        if (brain == null)
        {
            return;
        }

        float normalizedIdle = maxIdleTime <= 0.0001f
            ? 0f
            : Mathf.Clamp01(idleTime / maxIdleTime);

        brain.SetInputRaw("idleTime", normalizedIdle);
        // Sensors now handle recentEnemyThreat via a RecentAnyInRadius sensor.
        brain.SetInputRaw("enemyOnWanderPath", IsEnemyOnWanderPath() ? 1f : 0f);
        brain.SetInputRaw("wanderTargetEnemyDistance", GetNormalizedWanderTargetEnemyDistance());
    }

    private float GetMetabolicStress()
    {
        if (brain == null)
        {
            return 0f;
        }

        FeatureNode node = brain.GetFeatureNode("MetabolicStress");
        if (node == null)
        {
            return 0f;
        }

        return Mathf.Clamp01(node.Value);
    }

    private float GetRecoveryNeed()
    {
        if (brain == null)
        {
            return 0f;
        }

        FeatureNode node = brain.GetFeatureNode("RecoveryNeed");
        if (node == null)
        {
            return 0f;
        }

        return Mathf.Clamp01(node.Value);
    }

    private void CheckDeath()
    {
        // Check if the agent's energy has been depleted
        if (sensors.GetValue(energySignalId) <= 0f)
        {
            Die();
        }
    }

    private void Die()
    {
        learningState?.Apply("isDead", 1f, false);

        if (wanderEpisodeActive && learningController != null)
        {
            learningController.EndEpisode();
            wanderEpisodeActive = false;
        }

        isDead = true;
        currentPayload = "Dead";
        wanderCommitted = false;
        hasWanderTarget = false;
        controller.Stop();

        if (logDecisions)
        {
            Debug.Log("Creature died.", this);
        }
    }

    private void EvaluateDecision()
    {
        if (brain == null || sensors == null || isDead)
        {
            return;
        }

        sensors.Sense();
        // Update last known enemy position based on current sensing
        UpdateLastKnownEnemyPosition();
        UpdateBrainRuntimeInputs();

        brain.EvaluateAll();

        if (wanderEpisodeActive && learningController != null)
        {
            learningController.RecordStep();
        }

        List<RetrievalCandidate> candidates = brain.QueryCloudCandidates();
        DecisionResult result = DecisionFilter.SelectFirstValid(candidates, sensors);

        string proposedPayload = result.PayloadId ?? "Idle";
        string nextPayload = ResolveCommittedState(proposedPayload);

        if (logDecisions)
        {
            // Log key decision metrics. The recent enemy threat is now handled by sensors,
            // so we omit it from this debug output. If desired, retrieve the value via
            // sensors.GetValue("recentEnemyThreat").
            Debug.Log(
                $"Proposed={proposedPayload} Final={nextPayload} idleTime={idleTime:F2}/{maxIdleTime:F2} committed={wanderCommitted} stress={GetMetabolicStress():F2} recovery={GetRecoveryNeed():F2}",
                this);
        }

        if (currentPayload != nextPayload)
        {
            OnPayloadChanged(currentPayload, nextPayload);
        }

        currentPayload = nextPayload;
    }

    /// <summary>
    /// Updates the last known enemy position based on the nearest enemy.  Sensors
    /// now handle threat memory, so we no longer maintain an explicit timer here.
    /// If an enemy is found, its position is recorded for path checks; otherwise
    /// the previous position is retained.
    /// </summary>
    private void UpdateLastKnownEnemyPosition()
    {
        WorldTarget enemy = FindNearestTarget(enemyTag);
        if (enemy == null)
        {
            return;
        }

        lastKnownEnemyPosition = enemy.transform.position;
        hasLastKnownEnemyPosition = true;
    }

    // The concept of a recent enemy threat is now handled by sensors.  This
    // method is retained for backward compatibility but no longer used.

    private string ResolveCommittedState(string proposedPayload)
    {
        if (wanderCommitted)
        {
            if (proposedPayload == "SeekFood" || proposedPayload == "FleeEnemy")
            {
                wanderCommitted = false;
                return proposedPayload;
            }

            if (proposedPayload == "RepickTarget")
            {
                return proposedPayload;
            }

            if (idleTime > 0f)
            {
                return "Wander";
            }

            wanderCommitted = false;
            return "Idle";
        }

        if (proposedPayload == "Wander" && idleTime >= maxIdleTime)
        {
            wanderCommitted = true;
            return "Wander";
        }

        if (proposedPayload == "Wander" && idleTime < maxIdleTime)
        {
            return "Idle";
        }

        return proposedPayload;
    }

    private void OnPayloadChanged(string previousPayload, string nextPayload)
    {
        if (previousPayload == "Wander" && nextPayload != "Wander")
        {
            if (wanderEpisodeActive && learningController != null)
            {
                learningController.EndEpisode();
            }

            wanderEpisodeActive = false;
        }

        if (nextPayload == "FleeEnemy")
        {
            wanderCommitted = false;
            hasWanderTarget = false;
            wanderRetargetTimer = 0f;
        }

        if (nextPayload == "Wander")
        {
            if (!wanderEpisodeActive)
            {
                wanderEpisodeActive = true;

                if (learningController != null)
                {
                    learningController.BeginEpisode("Wander");
                }
            }

            if (!hasWanderTarget)
            {
                PickNewWanderTarget();
            }

            wanderRetargetTimer = retargetInterval;
        }
        else if (nextPayload == "Idle")
        {
            controller.Stop();
        }
    }

    private void ExecuteCurrentPayload(float deltaTime)
    {
        switch (currentPayload)
        {
            case "SeekFood":
                MoveToFood();
                break;

            case "FleeEnemy":
                FleeEnemy();
                break;

            case "Wander":
                Wander(deltaTime);
                break;

            case "RepickTarget":
                RepickTarget();
                break;

            case "Idle":
                Idle();
                break;

            case "Dead":
            default:
                controller.Stop();
                break;
        }
    }

    private void MoveToFood()
    {
        WorldTarget food = FindNearestTarget(foodTag);
        if (food == null)
        {
            currentPayload = "Idle";
            controller.Stop();
            return;
        }

        float distance = MathUtil.DistanceXZ(transform.position, food.transform.position);
        if (distance <= eatDistance)
        {
            ConsumeFood(food.gameObject);
            controller.Stop();
            return;
        }

        Vector3 dir = MathUtil.DirectionXZ(transform.position, food.transform.position);
        controller.Move(dir * moveStrength);
    }

    private void FleeEnemy()
    {
        WorldTarget enemy = FindNearestTarget(enemyTag);
        if (enemy == null)
        {
            currentPayload = "Idle";
            controller.Stop();
            return;
        }

        lastKnownEnemyPosition = enemy.transform.position;
        hasLastKnownEnemyPosition = true;

        Vector3 dir = MathUtil.DirectionXZ(enemy.transform.position, transform.position);
        if (dir.sqrMagnitude <= 0.0001f)
        {
            controller.Stop();
            return;
        }

        controller.Move(dir * moveStrength);
    }

    private void Wander(float deltaTime)
    {
        if (levelBounds == null)
        {
            Idle();
            return;
        }

        if (!hasWanderTarget)
        {
            PickNewWanderTarget();
        }

        wanderRetargetTimer -= deltaTime;
        wanderTarget = levelBounds.ClampPointInside(wanderTarget);

        float distanceToTarget = MathUtil.DistanceXZ(transform.position, wanderTarget);

        if (distanceToTarget <= minTargetDistance)
        {
            PickNewWanderTarget();
            wanderRetargetTimer = retargetInterval;
        }
        else if (wanderRetargetTimer <= 0f)
        {
            PickNewWanderTarget();
            wanderRetargetTimer = retargetInterval;
        }
        if(wanderTransform)
            wanderTransform.position = wanderTarget;
        Vector3 dir = MathUtil.DirectionXZ(transform.position, wanderTarget);
        if (dir.sqrMagnitude <= 0.0001f)
        {
            controller.Stop();
            return;
        }

        controller.Move(dir * moveStrength);
    }

    private void RepickTarget()
    {
        hasWanderTarget = false;
        PickNewWanderTarget();
        wanderRetargetTimer = retargetInterval;
        currentPayload = "Wander";
    }

    private void Idle()
    {
        controller.Stop();
    }

    private void PickNewWanderTarget()
    {
        if (levelBounds == null)
        {
            wanderTarget = transform.position;
            hasWanderTarget = false;
            return;
        }

        Bounds bounds = GetLevelBounds();

        bool canChainFromPrevious = hasWanderTarget && chainFromPreviousTarget;
        bool usePreviousAsReference = canChainFromPrevious && Random.value <= previousTargetBias;

        Vector3 referencePoint = usePreviousAsReference
            ? wanderTarget
            : transform.position;

        float localMinDistance = usePreviousAsReference
            ? Mathf.Max(minTargetDistance, minDistanceFromCurrentWhenChained)
            : minTargetDistance;

        Vector3 forwardDir = GetWanderForwardDirection();
        Vector3 proposed = PickBiasedWanderPoint(
            bounds,
            referencePoint,
            localMinDistance,
            wanderDistance,
            forwardDir,
            forwardBias
        );

        proposed = levelBounds.ClampPointInside(proposed);

        if (usePreviousAsReference)
        {
            float distanceFromCurrent = MathUtil.DistanceXZ(transform.position, proposed);
            if (distanceFromCurrent < minDistanceFromCurrentWhenChained)
            {
                proposed = PickBiasedWanderPoint(
                    bounds,
                    transform.position,
                    minTargetDistance,
                    wanderDistance,
                    forwardDir,
                    forwardBias
                );

                proposed = levelBounds.ClampPointInside(proposed);
            }
        }

        wanderTarget = proposed;
        hasWanderTarget = true;

        if (logDecisions)
        {
            float distanceFromCurrent = MathUtil.DistanceXZ(transform.position, wanderTarget);
            Debug.Log(
                $"New Wander Target | ref={(usePreviousAsReference ? "previous" : "current")} target={wanderTarget} distanceFromCurrent={distanceFromCurrent:F2}",
                this);
        }
    }

    private Vector3 PickBiasedWanderPoint(
        Bounds bounds,
        Vector3 referencePoint,
        float minDistanceLocal,
        float maxDistanceLocal,
        Vector3 forwardDir,
        float forwardBiasLocal)
    {
        minDistanceLocal = Mathf.Max(0f, minDistanceLocal);
        maxDistanceLocal = Mathf.Max(minDistanceLocal, maxDistanceLocal);

        if (forwardDir.sqrMagnitude <= 0.0001f || forwardBiasLocal <= 0f)
        {
            return MathUtil.RandomPointInBounds(bounds, referencePoint, maxDistanceLocal, minDistanceLocal);
        }

        float distance = Random.Range(minDistanceLocal, maxDistanceLocal);

        Vector3 randomDir = MathUtil.RandomDirectionXZ();
        Vector3 blendedDir = (randomDir * (1f - forwardBiasLocal)) + (forwardDir.normalized * forwardBiasLocal);
        blendedDir.y = 0f;

        if (blendedDir.sqrMagnitude <= 0.0001f)
        {
            blendedDir = randomDir;
        }
        else
        {
            blendedDir.Normalize();
        }

        Vector3 point = referencePoint + blendedDir * distance;
        point.x = Mathf.Clamp(point.x, bounds.min.x, bounds.max.x);
        point.z = Mathf.Clamp(point.z, bounds.min.z, bounds.max.z);
        point.y = bounds.center.y;

        return point;
    }

    private Vector3 GetWanderForwardDirection()
    {
        if (hasWanderTarget)
        {
            Vector3 targetDir = MathUtil.DirectionXZ(transform.position, wanderTarget);
            if (targetDir.sqrMagnitude > 0.0001f)
            {
                return targetDir;
            }
        }

        Vector3 forward = transform.forward;
        forward.y = 0f;

        if (forward.sqrMagnitude > 0.0001f)
        {
            return forward.normalized;
        }

        return Vector3.zero;
    }

    private float GetNormalizedWanderTargetEnemyDistance()
    {
        if (!hasWanderTarget || !hasLastKnownEnemyPosition)
        {
            return 1f;
        }

        float distance = MathUtil.DistanceXZ(wanderTarget, lastKnownEnemyPosition);
        return Mathf.Clamp01(distance / Mathf.Max(0.001f, wanderTargetEnemyDistanceMax));
    }

    private bool IsEnemyOnWanderPath()
    {
        if (!hasWanderTarget || !hasLastKnownEnemyPosition)
        {
            return false;
        }

        Vector3 a = transform.position;
        Vector3 b = wanderTarget;
        Vector3 p = lastKnownEnemyPosition;

        a.y = 0f;
        b.y = 0f;
        p.y = 0f;

        Vector3 ab = b - a;
        float abLenSq = ab.sqrMagnitude;

        if (abLenSq <= 0.0001f)
        {
            return false;
        }

        float t = Vector3.Dot(p - a, ab) / abLenSq;
        t = Mathf.Clamp01(t);

        Vector3 closest = a + ab * t;
        float distanceToPath = MathUtil.DistanceXZ(closest, p);

        return distanceToPath <= enemyPathCheckRadius;
    }

    private Bounds GetLevelBounds()
    {
        return levelBounds.GetWorldBounds();
    }

    private void ConsumeFood(GameObject food)
    {
        learningState?.Apply("foodConsumed", 1f, true);
        // Reduce hunger and restore energy on food consumption.  If corresponding
        // sensors exist for these signal IDs and are state drift sensors, they
        // will handle clamping to their configured min/max values.  Otherwise,
        // the Sensors container will clamp the values to [0,1].
        sensors.ApplyToSignal(hungerSignalId, -hungerRestore);
        sensors.ApplyToSignal(energySignalId, energyRestoreOnEat);

        Destroy(food);

        currentPayload = "Idle";
        idleTime = 0f;
        wanderCommitted = false;
        hasWanderTarget = false;
    }

    /// <summary>
    /// Finds the nearest WorldTarget with the specified tag.  Searches the
    /// WorldTargetRegistry for targets and returns the closest one to this
    /// creature.  Returns null if no such target exists.
    /// </summary>
    private WorldTarget FindNearestTarget(string tag)
    {
        if (string.IsNullOrWhiteSpace(tag))
        {
            return null;
        }

        IReadOnlyList<WorldTarget> targets = WorldTargetRegistry.GetTargetsByTag(tag);
        if (targets == null || targets.Count == 0)
        {
            return null;
        }

        WorldTarget nearest = null;
        float bestSqrDistance = float.MaxValue;
        Vector3 myPos = transform.position;
        for (int i = 0; i < targets.Count; i++)
        {
            WorldTarget wt = targets[i];
            if (wt == null)
            {
                continue;
            }
            Vector3 delta = wt.transform.position - myPos;
            float sqr = delta.sqrMagnitude;
            if (sqr < bestSqrDistance)
            {
                bestSqrDistance = sqr;
                nearest = wt;
            }
        }
        return nearest;
    }

    /// <summary>
    /// Adds the specified delta to the agent's energy signal and clamps the
    /// result between 0 and 1.
    /// </summary>
    private void ModifyEnergy(float delta)
    {
        if (sensors == null || string.IsNullOrWhiteSpace(energySignalId))
        {
            return;
        }
        // Delegate the delta application to the Sensors container.  If an
        // energy sensor of type StateDrift exists, it will clamp according
        // to its own min/max range; otherwise, the container will clamp
        // the value between 0 and 1.
        sensors.ApplyToSignal(energySignalId, delta);
    }

    private void OnDrawGizmosSelected()
    {
        if (!drawWanderTarget)
        {
            return;
        }

        if (hasWanderTarget)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawSphere(wanderTarget, 0.25f);
            Gizmos.DrawLine(transform.position, wanderTarget);
        }
    }
}