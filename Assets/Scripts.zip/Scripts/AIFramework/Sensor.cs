using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enumerates the different kinds of sensing behaviours supported by a <see cref="Sensor"/>.
/// External sensors query the world and output a value based on proximity or count,
/// whereas internal sensors drift a state value over time.  Additional behaviours can
/// be added by extending this enumeration and the switch logic in <see cref="Sensor.Update"/>.
/// </summary>
public enum SensorType
{
    /// <summary>
    /// Finds the nearest matching object within the configured radius and outputs
    /// a normalised proximity value between 0 and 1.  A value of 0 means no target
    /// was within the radius, whereas 1 means the target was at the same position
    /// as the agent.  Values in-between are inversely proportional to the
    /// distance as a fraction of the radius.
    /// </summary>
    NearestProximity,

    /// <summary>
    /// Counts all matching objects within the configured radius and returns the raw
    /// count as a float.  Use this to sense how many objects are nearby.
    /// </summary>
    CountInRadius,

    /// <summary>
    /// Returns 1 if any matching object is within the configured radius; otherwise
    /// returns 0.  This can be used to trigger behaviours based on the presence of
    /// specific objects.
    /// </summary>
    AnyInRadius,

    /// <summary>
    /// Represents an internal state that drifts over time.  This is useful for
    /// modelling needs such as hunger or fatigue.  The value drifts at a
    /// configurable rate and is clamped between a minimum and maximum.
    /// </summary>
    StateDrift

    ,

    /// <summary>
    /// Similar to <see cref="AnyInRadius"/>, but retains a value of 1 for a
    /// configurable duration after a detection event.  Use this to model
    /// short‑term threat memory (e.g. recent enemy presence) where the signal
    /// remains true for a few seconds even when the enemy has moved out of
    /// range.
    /// </summary>
    RecentAnyInRadius
}

/// <summary>
/// Specifies how a sensor treats its target set with respect to world dynamics.
/// <list type="bullet">
/// <item>
/// <term>Static</term>
/// <description>The set of targets is assumed to be fixed for the lifetime of the sensor.
/// Targets may move, but no new targets are expected to appear or disappear.
/// The sensor caches the targets once during <see cref="Initialize"/> and reuses
/// the cache for subsequent updates.</description>
/// </item>
/// <item>
/// <term>NonStatic</term>
/// <description>The set of targets is also assumed to be fixed, but targets are expected
/// to move during gameplay.  This is equivalent to <see cref="Static"/> for the
/// purposes of caching, but the name clarifies intent.</description>
/// </item>
/// <item>
/// <term>Dynamic</term>
/// <description>Targets can spawn and despawn at runtime.  The sensor does not
/// maintain a cache of targets and instead queries the physics system each update
/// using <see cref="Physics.OverlapSphereNonAlloc"/>.  This avoids stale
/// references at the expense of a more expensive query.</description>
/// </item>
/// </list>
/// </summary>
public enum SensorMobility
{
    Static,
    NonStatic,
    Dynamic
}

/// <summary>
/// Specifies which transform should be used as the origin when computing
/// distances or proximity for external sensors.  <see cref="Owner"/> uses
/// the owning creature's transform passed into <see cref="Sensor.Update"/>,
/// whereas <see cref="Custom"/> uses a user‑assigned <see cref="Transform"/>
/// reference on the sensor.  This allows sensors to measure distances from
/// arbitrary points such as a wander target instead of the creature itself.
/// </summary>
public enum SensorOrigin
{
    /// <summary>
    /// Use the agent's transform passed into <see cref="Sensor.Update"/> as
    /// the origin for distance calculations.
    /// </summary>
    Owner,

    /// <summary>
    /// Use a custom <see cref="Transform"/> specified on the sensor as
    /// the origin.  If no custom transform is assigned, falls back to
    /// <see cref="Owner"/>.
    /// </summary>
    Custom
}

/// <summary>
/// Represents a single sensor configuration and its runtime state.  A sensor
/// writes its computed value into a <see cref="Signal"/> on the owning
/// <see cref="Sensors"/> component.  Sensors are serialisable and intended to be
/// configured via the Unity Inspector.  They do not hold a direct reference
/// to the <see cref="Sensors"/> container; instead the owner supplies it when
/// invoking <see cref="Initialize"/> and <see cref="Update"/>.
/// </summary>
[Serializable]
public class Sensor
{
    [SerializeField] private SensorType type = SensorType.NearestProximity;
    [SerializeField] private SensorMobility mobility = SensorMobility.Static;
    [SerializeField] private string signalId = string.Empty;

    // External sensing configuration
    [Header("External Sensor Settings")]
    [SerializeField] private LayerMask layerMask = ~0;
    [SerializeField] private string tagFilter = string.Empty;
    [SerializeField] private float radius = 10f;

    // Internal state drift configuration
    [Header("State Drift Settings")]
    [SerializeField] private float driftPerSecond = 0.05f;
    [SerializeField] private float initialValue = 0f;
    [SerializeField] private float minValue = 0f;
    [SerializeField] private float maxValue = 1f;

    // Recent sensor configuration
    [Header("Recent Any In Radius Settings")]
    [SerializeField] private float recentMemoryDuration = 1f;

    // Origin selection
    [Header("Origin Settings")]
    [SerializeField] private SensorOrigin originMode = SensorOrigin.Owner;
    [SerializeField] private Transform customOrigin;

    // Runtime state for StateDrift and caching
    [NonSerialized] private float stateValue;
    [NonSerialized] private List<Transform> cachedTargets;
    [NonSerialized] private Collider[] overlapBuffer;

    // Runtime state for recent memory
    [NonSerialized] private float recentMemoryRemaining;

    /// <summary>
    /// Provides access to the sensor type.  Exposed via a property for custom
    /// drawers and runtime inspection.
    /// </summary>
    public SensorType Type
    {
        get => type;
        set => type = value;
    }

    /// <summary>
    /// Indicates how the sensor should treat its target set with respect to
    /// changes at runtime.  See <see cref="SensorMobility"/> for definitions.
    /// </summary>
    public SensorMobility Mobility
    {
        get => mobility;
        set => mobility = value;
    }

    /// <summary>
    /// Gets or sets the identifier of the signal this sensor writes to.  The
    /// owner should ensure that each sensor writes to a unique id unless
    /// deliberately sharing a signal.
    /// </summary>
    public string SignalId
    {
        get => signalId;
        set => signalId = value;
    }

    /// <summary>
    /// Radius within which objects are considered by external sensors.  Ignored
    /// for <see cref="SensorType.StateDrift"/>.
    /// </summary>
    public float Radius
    {
        get => radius;
        set => radius = value;
    }

    /// <summary>
    /// Tag used to filter objects when performing external sensing.  If empty
    /// or whitespace, all objects on the specified layers are considered.
    /// </summary>
    public string TagFilter
    {
        get => tagFilter;
        set => tagFilter = value;
    }

    /// <summary>
    /// Bitmask specifying which layers to consider when sensing.  The default
    /// value (~0) includes all layers.
    /// </summary>
    public LayerMask LayerMask
    {
        get => layerMask;
        set => layerMask = value;
    }

    /// <summary>
    /// Rate at which the state drifts per second when using
    /// <see cref="SensorType.StateDrift"/>.  Positive values increase the
    /// state; negative values decrease it.  Ignored for other types.
    /// </summary>
    public float DriftPerSecond
    {
        get => driftPerSecond;
        set => driftPerSecond = value;
    }

    /// <summary>
    /// Minimum value for state drift sensors.  The state will be clamped to
    /// this value.
    /// </summary>
    public float MinValue
    {
        get => minValue;
        set => minValue = value;
    }

    /// <summary>
    /// Maximum value for state drift sensors.  The state will be clamped to
    /// this value.
    /// </summary>
    public float MaxValue
    {
        get => maxValue;
        set => maxValue = value;
    }

    /// <summary>
    /// Initial value used for state drift sensors.  Values outside the
    /// [minValue,maxValue] range are clamped during initialisation.
    /// </summary>
    public float InitialValue
    {
        get => initialValue;
        set => initialValue = value;
    }

    /// <summary>
    /// Duration in seconds that a <see cref="SensorType.RecentAnyInRadius"/>
    /// sensor remains active after detecting a target.  When set to zero,
    /// the sensor behaves like <see cref="SensorType.AnyInRadius"/>.
    /// </summary>
    public float RecentMemoryDuration
    {
        get => recentMemoryDuration;
        set => recentMemoryDuration = value;
    }

    /// <summary>
    /// Specifies which transform to use as the origin when computing
    /// distances for external sensors.  See <see cref="SensorOrigin"/>.
    /// </summary>
    public SensorOrigin OriginMode
    {
        get => originMode;
        set => originMode = value;
    }

    /// <summary>
    /// Custom origin transform used when <see cref="OriginMode"/> is set
    /// to <see cref="SensorOrigin.Custom"/>.  If this is null, the
    /// owning transform provided to <see cref="Update"/> is used instead.
    /// </summary>
    public Transform CustomOrigin
    {
        get => customOrigin;
        set => customOrigin = value;
    }

    /// <summary>
    /// Initialises this sensor for the given container.  This method ensures
    /// that the output signal exists on the container and performs any
    /// necessary caching depending on the <see cref="SensorMobility"/>.  It
    /// should be called once, typically from <see cref="MonoBehaviour.Awake"/>
    /// on the owning <see cref="Sensors"/>.
    /// </summary>
    /// <param name="container">The sensors container that holds the output signals.</param>
    /// <param name="origin">The transform representing the agent's position.  Used only
    /// for caching static and non-static targets when required.</param>
    public void Initialize(Sensors container, Transform origin)
    {
        // Initialise state for drift sensors
        stateValue = Mathf.Clamp(initialValue, minValue, maxValue);

        // Ensure the target signal exists on the container.  Use float type for all sensors.
        if (container != null && !string.IsNullOrWhiteSpace(signalId))
        {
            float initialSignalValue = type == SensorType.StateDrift ? stateValue : 0f;
            container.EnsureSignal(signalId, SignalType.Float, initialSignalValue);
        }

        // Build the target cache for static and non-static sensors
        if (type != SensorType.StateDrift && mobility != SensorMobility.Dynamic)
        {
            BuildTargetCache(origin);
        }

        // Allocate the overlap buffer for dynamic sensors.  Choose a reasonable default size.
        if (mobility == SensorMobility.Dynamic && overlapBuffer == null)
        {
            // 64 should be sufficient for most scenarios.  Users can adjust this
            // by modifying this value or exposing it via the inspector if needed.
            overlapBuffer = new Collider[64];
        }

        // Reset recent memory state
        recentMemoryRemaining = 0f;
    }

    /// <summary>
    /// Updates this sensor and writes the computed value into the container.  The
    /// owner should call this once per frame from its own Update or Sense
    /// method, passing in the delta time and the agent's transform.
    /// </summary>
    /// <param name="container">The sensors container to which the value is written.</param>
    /// <param name="deltaTime">Time elapsed since the previous update.</param>
    /// <param name="origin">The transform representing the agent's position.</param>
    public void Update(Sensors container, float deltaTime, Transform origin)
    {
        if (container == null || string.IsNullOrWhiteSpace(signalId))
        {
            return;
        }

        // Determine which transform to use as the origin for external sensors.
        Transform usedOrigin = origin;
        if (originMode == SensorOrigin.Custom && customOrigin != null)
        {
            usedOrigin = customOrigin;
        }

        float newValue;
        switch (type)
        {
            case SensorType.NearestProximity:
                newValue = ComputeNearestProximity(usedOrigin);
                break;
            case SensorType.CountInRadius:
                newValue = ComputeCountInRadius(usedOrigin);
                break;
            case SensorType.AnyInRadius:
                newValue = ComputeAnyInRadius(usedOrigin);
                break;
            case SensorType.StateDrift:
                newValue = UpdateStateDrift(deltaTime);
                break;
            case SensorType.RecentAnyInRadius:
                newValue = ComputeRecentAnyInRadius(usedOrigin, deltaTime);
                break;
            default:
                newValue = 0f;
                break;
        }

        container.SetSignal(signalId, newValue);
    }

    /// <summary>
    /// Applies a delta to this sensor's internal state.  This is primarily
    /// intended for <see cref="SensorType.StateDrift"/> sensors, allowing
    /// external systems to replenish or drain the state (e.g. restoring
    /// hunger or energy).  If the sensor is not a state drift sensor, this
    /// method has no effect.  The updated value is clamped between
    /// <see cref="minValue"/> and <see cref="maxValue"/> and written back
    /// into the container's signal.
    /// </summary>
    /// <param name="delta">The amount to add to the internal state.  Positive
    /// values replenish the state, negative values drain it.</param>
    /// <param name="container">The sensors container that holds the output
    /// signal.  This is required to update the stored signal value.</param>
    public void ApplyStateDelta(float delta, Sensors container)
    {
        if (type != SensorType.StateDrift)
        {
            // Only state drift sensors maintain internal state that can be
            // replenished.  Other sensor types ignore this call.
            return;
        }

        // Apply the delta to the runtime state and clamp between min/max.
        stateValue += delta;
        stateValue = Mathf.Clamp(stateValue, minValue, maxValue);

        // Write the clamped value back to the container's signal.
        if (container != null && !string.IsNullOrWhiteSpace(signalId))
        {
            container.SetSignal(signalId, stateValue);
        }
    }

    /// <summary>
    /// Computes a normalised proximity value based on the nearest matching
    /// transform.  Returns 0 if no targets are within the radius.
    /// </summary>
    private float ComputeNearestProximity(Transform origin)
    {
        if (origin == null || radius <= 0f)
        {
            return 0f;
        }

        float bestDistance = float.MaxValue;
        float radiusSqr = radius * radius;

        if (mobility == SensorMobility.Dynamic)
        {
            bool usedRegistry = false;
            // If a tag filter is specified and registered targets exist for that tag,
            // iterate over the registry instead of performing a physics query.  This
            // avoids the cost of OverlapSphere for dynamic sensors.
            IReadOnlyList<WorldTarget> targetList;
            if (!string.IsNullOrWhiteSpace(tagFilter))
            {
                targetList = WorldTargetRegistry.GetTargetsByTag(tagFilter);
            }
            else
            {
                targetList = WorldTargetRegistry.AllTargets;
            }
            if (targetList != null && targetList.Count > 0)
            {
                usedRegistry = true;
                for (int i = 0; i < targetList.Count; i++)
                {
                    WorldTarget wt = targetList[i];
                    if (wt == null)
                    {
                        continue;
                    }
                    GameObject go = wt.gameObject;
                    // Filter by layer
                    int objLayer = go.layer;
                    if (((1 << objLayer) & layerMask) == 0)
                    {
                        continue;
                    }
                    // Compute squared distance
                    Vector3 delta = wt.transform.position - origin.position;
                    float sqrDistance = delta.sqrMagnitude;
                    if (sqrDistance > radiusSqr)
                    {
                        continue;
                    }
                    if (sqrDistance < bestDistance)
                    {
                        bestDistance = sqrDistance;
                    }
                }
            }
            // Fallback to physics query if the registry did not supply any targets.
            if (!usedRegistry)
            {
                int hitCount = Physics.OverlapSphereNonAlloc(origin.position, radius, overlapBuffer, layerMask);
                for (int i = 0; i < hitCount; i++)
                {
                    Collider col = overlapBuffer[i];
                    if (col == null)
                    {
                        continue;
                    }
                    GameObject go = col.gameObject;
                    // Filter by tag if specified
                    if (!string.IsNullOrWhiteSpace(tagFilter) && !go.CompareTag(tagFilter))
                    {
                        continue;
                    }
                    // Compute squared distance using the closest point on the collider
                    Vector3 closest = col.ClosestPoint(origin.position);
                    Vector3 delta = closest - origin.position;
                    float sqrDistance = delta.sqrMagnitude;
                    if (sqrDistance < bestDistance)
                    {
                        bestDistance = sqrDistance;
                    }
                }
            }
        }
        else
        {
            // Use the cached target list for static and non-static sensors
            if (cachedTargets == null || cachedTargets.Count == 0)
            {
                return 0f;
            }
            for (int i = 0; i < cachedTargets.Count; i++)
            {
                Transform target = cachedTargets[i];
                if (target == null)
                {
                    continue;
                }
                // Skip if outside the radius
                Vector3 delta = target.position - origin.position;
                float sqrDistance = delta.sqrMagnitude;
                if (sqrDistance > radiusSqr)
                {
                    continue;
                }
                if (sqrDistance < bestDistance)
                {
                    bestDistance = sqrDistance;
                }
            }
        }

        if (bestDistance == float.MaxValue)
        {
            return 0f;
        }

        // Convert squared distance to normalised proximity
        float distance = Mathf.Sqrt(bestDistance);
        float normalized = Mathf.Clamp01(distance / radius);
        return 1f - normalized;
    }

    /// <summary>
    /// Counts how many targets are within the radius.  Returns the raw count.
    /// </summary>
    private float ComputeCountInRadius(Transform origin)
    {
        if (origin == null || radius <= 0f)
        {
            return 0f;
        }
        int count = 0;
        float radiusSqr = radius * radius;

        if (mobility == SensorMobility.Dynamic)
        {
            bool usedRegistry = false;
            // Try to use the registry when a tag filter exists or there are registered targets
            IReadOnlyList<WorldTarget> targetList;
            if (!string.IsNullOrWhiteSpace(tagFilter))
            {
                targetList = WorldTargetRegistry.GetTargetsByTag(tagFilter);
            }
            else
            {
                targetList = WorldTargetRegistry.AllTargets;
            }
            if (targetList != null && targetList.Count > 0)
            {
                usedRegistry = true;
                for (int i = 0; i < targetList.Count; i++)
                {
                    WorldTarget wt = targetList[i];
                    if (wt == null)
                    {
                        continue;
                    }
                    GameObject go = wt.gameObject;
                    // Filter by layer
                    int objLayer = go.layer;
                    if (((1 << objLayer) & layerMask) == 0)
                    {
                        continue;
                    }
                    Vector3 delta = wt.transform.position - origin.position;
                    float sqrDistance = delta.sqrMagnitude;
                    if (sqrDistance <= radiusSqr)
                    {
                        count++;
                    }
                }
            }
            // Fallback to physics query if no registered targets were used
            if (!usedRegistry)
            {
                int hitCount = Physics.OverlapSphereNonAlloc(origin.position, radius, overlapBuffer, layerMask);
                var uniqueTransforms = new HashSet<Transform>();
                for (int i = 0; i < hitCount; i++)
                {
                    Collider col = overlapBuffer[i];
                    if (col == null)
                    {
                        continue;
                    }
                    GameObject go = col.gameObject;
                    if (!string.IsNullOrWhiteSpace(tagFilter) && !go.CompareTag(tagFilter))
                    {
                        continue;
                    }
                    uniqueTransforms.Add(col.transform);
                }
                count = uniqueTransforms.Count;
            }
        }
        else
        {
            if (cachedTargets == null || cachedTargets.Count == 0)
            {
                return 0f;
            }
            for (int i = 0; i < cachedTargets.Count; i++)
            {
                Transform target = cachedTargets[i];
                if (target == null)
                {
                    continue;
                }
                Vector3 delta = target.position - origin.position;
                float sqrDistance = delta.sqrMagnitude;
                if (sqrDistance <= radiusSqr)
                {
                    count++;
                }
            }
        }

        return count;
    }

    /// <summary>
    /// Returns 1 if any target is within the radius; otherwise returns 0.
    /// </summary>
    private float ComputeAnyInRadius(Transform origin)
    {
        if (origin == null || radius <= 0f)
        {
            return 0f;
        }
        float radiusSqr = radius * radius;

        if (mobility == SensorMobility.Dynamic)
        {
            // Try to use registry first
            IReadOnlyList<WorldTarget> targetList;
            if (!string.IsNullOrWhiteSpace(tagFilter))
            {
                targetList = WorldTargetRegistry.GetTargetsByTag(tagFilter);
            }
            else
            {
                targetList = WorldTargetRegistry.AllTargets;
            }
            if (targetList != null && targetList.Count > 0)
            {
                for (int i = 0; i < targetList.Count; i++)
                {
                    WorldTarget wt = targetList[i];
                    if (wt == null)
                    {
                        continue;
                    }
                    GameObject go = wt.gameObject;
                    // Filter by layer
                    int objLayer = go.layer;
                    if (((1 << objLayer) & layerMask) == 0)
                    {
                        continue;
                    }
                    Vector3 delta = wt.transform.position - origin.position;
                    float sqrDistance = delta.sqrMagnitude;
                    if (sqrDistance <= radiusSqr)
                    {
                        return 1f;
                    }
                }
                return 0f;
            }
            // Fallback to physics query if registry has no targets
            int hitCount = Physics.OverlapSphereNonAlloc(origin.position, radius, overlapBuffer, layerMask);
            for (int i = 0; i < hitCount; i++)
            {
                Collider col = overlapBuffer[i];
                if (col == null)
                {
                    continue;
                }
                GameObject go = col.gameObject;
                if (!string.IsNullOrWhiteSpace(tagFilter) && !go.CompareTag(tagFilter))
                {
                    continue;
                }
                return 1f;
            }
            return 0f;
        }
        else
        {
            if (cachedTargets == null || cachedTargets.Count == 0)
            {
                return 0f;
            }
            for (int i = 0; i < cachedTargets.Count; i++)
            {
                Transform target = cachedTargets[i];
                if (target == null)
                {
                    continue;
                }
                Vector3 delta = target.position - origin.position;
                float sqrDistance = delta.sqrMagnitude;
                if (sqrDistance <= radiusSqr)
                {
                    return 1f;
                }
            }
            return 0f;
        }
    }

    /// <summary>
    /// Updates and returns the internal state for drift sensors.  The state
    /// incrementally moves towards the configured range by driftPerSecond and
    /// remains clamped between <see cref="minValue"/> and <see cref="maxValue"/>.
    /// </summary>
    private float UpdateStateDrift(float deltaTime)
    {
        stateValue += driftPerSecond * deltaTime;
        stateValue = Mathf.Clamp(stateValue, minValue, maxValue);
        return stateValue;
    }

    /// <summary>
    /// Computes a recent memory version of <see cref="AnyInRadius"/>.  When
    /// a target is detected, the memory timer is reset to
    /// <see cref="recentMemoryDuration"/>.  When no target is detected, the
    /// timer decreases by deltaTime.  The sensor outputs 1 while the timer
    /// is greater than zero and 0 when it expires.  This allows behaviours
    /// to react to targets that were recently present even if they are no
    /// longer within radius.
    /// </summary>
    private float ComputeRecentAnyInRadius(Transform origin, float deltaTime)
    {
        // Check for immediate detection using the standard any-in-radius logic.
        float detection = ComputeAnyInRadius(origin);
        if (detection > 0f)
        {
            recentMemoryRemaining = recentMemoryDuration;
        }
        else if (recentMemoryRemaining > 0f)
        {
            recentMemoryRemaining -= deltaTime;
        }
        // Clamp to zero if negative
        if (recentMemoryRemaining < 0f)
        {
            recentMemoryRemaining = 0f;
        }
        return recentMemoryRemaining > 0f ? 1f : 0f;
    }

    /// <summary>
    /// Builds a cache of target transforms for static and non-static sensors.
    /// This method uses <see cref="UnityEngine.Object.FindObjectsOfType"/> to
    /// gather all colliders in the scene and then filters them by layer and
    /// tag.  Because this call can be expensive, it is only executed during
    /// initialisation.  For dynamic sensors, no caching is performed and the
    /// physics system is queried each frame instead.
    /// </summary>
    private void BuildTargetCache(Transform origin)
    {
        cachedTargets = new List<Transform>();
        // We use Collider rather than GameObject to ensure the targets have
        // physical presence.  You could change this to find any components
        // relevant for sensing (e.g. a custom marker component) if needed.
        Collider[] allColliders = UnityEngine.Object.FindObjectsOfType<Collider>();
        for (int i = 0; i < allColliders.Length; i++)
        {
            Collider col = allColliders[i];
            GameObject go = col.gameObject;
            // Filter by layer
            int objLayer = go.layer;
            if (((1 << objLayer) & layerMask) == 0)
            {
                continue;
            }
            // Filter by tag
            if (!string.IsNullOrWhiteSpace(tagFilter) && !go.CompareTag(tagFilter))
            {
                continue;
            }
            cachedTargets.Add(col.transform);
        }
    }
}