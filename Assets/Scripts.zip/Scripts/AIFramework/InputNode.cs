using System;
using System.Collections.Generic;
using UnityEngine;

public enum InputValueType
{
    Float,
    Bool,
    Int
}

[Serializable]
public sealed class InputNode : NodeBase
{
    [SerializeField] private InputValueType valueType = InputValueType.Float;

    [Header("Normalization")]
    [SerializeField] private float minValue = 0f;
    [SerializeField] private float maxValue = 1f;
    [SerializeField] private bool clampNormalized = true;

    [Header("Runtime")]
    [SerializeField] private float rawValue;
    [SerializeField] private float normalizedValue;

    // ---------------------------------------------------------------------
    // Decision filter settings
    //
    // These fields allow an InputNode to participate in decision filtering.
    // When UseAsFilter is true, this input node's normalized value will be
    // compared against FilterThreshold for any payload listed in
    // FilterPayloads.  If the value is less than or equal to the threshold,
    // the corresponding behaviour will not be selected by the DecisionFilter.
    [Header("Decision Filter Settings")]
    [SerializeField] private bool useAsFilter = false;
    [SerializeField] private List<string> filterPayloads = new();
    [SerializeField] private float filterThreshold = 0f;

    public InputValueType ValueType => valueType;
    public float RawValue => rawValue;
    public float NormalizedValue => normalizedValue;
    public float MinValue => minValue;
    public float MaxValue => maxValue;

    public override float OutputValue => normalizedValue;

    /// <summary>
    /// Indicates whether this input node should be used to gate specific behaviour
    /// payloads during decision filtering.  When true, the payloads in
    /// <see cref="FilterPayloads"/> are checked against this node's value.
    /// </summary>
    public bool UseAsFilter => useAsFilter;

    /// <summary>
    /// List of behaviour payload identifiers that this input node gates.  If the
    /// current payload appears in this list and <see cref="UseAsFilter"/> is true,
    /// the input node's value will be compared against <see cref="FilterThreshold"/>.
    /// </summary>
    public IReadOnlyList<string> FilterPayloads => filterPayloads;

    /// <summary>
    /// Threshold for gating behaviours.  If the input node's normalized value is
    /// less than or equal to this threshold, the associated behaviour is
    /// considered invalid.  Default is zero.
    /// </summary>
    public float FilterThreshold => filterThreshold;

    public InputNode(
        string id,
        string displayName,
        InputValueType valueType = InputValueType.Float,
        float minValue = 0f,
        float maxValue = 1f) : base(id, displayName)
    {
        this.valueType = valueType;
        this.minValue = minValue;
        this.maxValue = maxValue;
    }

    public void SetRawValue(float value)
    {
        rawValue = value;
        normalizedValue = Normalize(value);
    }

    public void SetBoolValue(bool value)
    {
        rawValue = value ? 1f : 0f;
        normalizedValue = rawValue;
    }

    public void SetIntValue(int value)
    {
        rawValue = value;
        normalizedValue = Normalize(value);
    }

    public void Recalculate()
    {
        normalizedValue = Normalize(rawValue);
    }

    private float Normalize(float value)
    {
        return MathUtil.Normalize(value, minValue, maxValue, clampNormalized);
    }

    public override string ToString()
    {
        return $"{base.ToString()} Raw={rawValue:F3}, Normalized={normalizedValue:F3}";
    }
}
