using System.Collections.Generic;
using System;

public static class DecisionFilter
{
    public static DecisionResult SelectFirstValid(
        List<RetrievalCandidate> candidates,
        Sensors sensors)
    {
        if (candidates == null || candidates.Count == 0)
        {
            return new DecisionResult(null);
        }

        for (int i = 0; i < candidates.Count; i++)
        {
            RetrievalCandidate candidate = candidates[i];
            if (candidate == null || candidate.Record == null)
            {
                continue;
            }

            string payload = candidate.Record.PayloadId;

            if (IsValid(payload, sensors))
            {
                return new DecisionResult(candidate);
            }
        }

        return new DecisionResult(null);
    }

    private static bool IsValid(string payload, Sensors sensors)
    {
        // If sensors are not provided, assume the candidate is valid.
        if (sensors == null)
        {
            return true;
        }

        // Retrieve the brain from the sensors and inspect input nodes for
        // decision gating.  Input nodes can optionally gate behaviours via
        // their filter settings.  If a matching input node has a value less
        // than or equal to its threshold, the payload is invalid.
        DecisionBrain brain = sensors.Brain;
        if (brain != null)
        {
            IReadOnlyList<InputNode> inputs = brain.InputNodes;
            if (inputs != null)
            {
                for (int i = 0; i < inputs.Count; i++)
                {
                    InputNode node = inputs[i];
                    if (node == null || !node.UseAsFilter)
                    {
                        continue;
                    }

                    IReadOnlyList<string> payloads = node.FilterPayloads;
                    if (payloads == null || payloads.Count == 0)
                    {
                        continue;
                    }

                    // Check if the current payload is gated by this input node
                    for (int p = 0; p < payloads.Count; p++)
                    {
                        string gatedPayload = payloads[p];
                        if (string.Equals(gatedPayload, payload, StringComparison.Ordinal))
                        {
                            // Compare normalized value against threshold
                            float value = node.NormalizedValue;
                            if (value <= node.FilterThreshold)
                            {
                                return false;
                            }
                            // Otherwise this node allows the payload; continue checking others.
                            break;
                        }
                    }
                }
            }
        }

        // If no input nodes blocked the payload, consider it valid.
        return true;
    }
}