using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Maintains a registry of all <see cref="WorldTarget"/> instances currently
/// active in the scene.  Targets are indexed by their Unity tag to allow
/// efficient lookups for dynamic sensors.  A global list of all registered
/// targets is also maintained for sensors that do not specify a tag filter.
/// </summary>
public static class WorldTargetRegistry
{
    // Mapping from Unity tag to a list of targets with that tag.  The key is the
    // tag string.  Unity requires that tags are non-empty for tagged objects.
    private static readonly Dictionary<string, List<WorldTarget>> targetsByTag = new();

    // A list containing every registered target irrespective of tag.  Sensors
    // without a tag filter can iterate over this list.
    private static readonly List<WorldTarget> allTargets = new();

    /// <summary>
    /// Gets a read-only list of all targets with the specified tag.  If no
    /// targets exist for the tag, an empty array is returned.  The returned
    /// collection should not be modified.
    /// </summary>
    /// <param name="tag">The Unity tag to look up.</param>
    public static IReadOnlyList<WorldTarget> GetTargetsByTag(string tag)
    {
        if (string.IsNullOrWhiteSpace(tag))
        {
            return Array.Empty<WorldTarget>();
        }
        return targetsByTag.TryGetValue(tag, out List<WorldTarget> list) ? list : Array.Empty<WorldTarget>();
    }

    /// <summary>
    /// Gets a read-only list containing all registered targets.  Sensors
    /// that do not specify a tag filter can iterate over this list.
    /// </summary>
    public static IReadOnlyList<WorldTarget> AllTargets => allTargets;

    /// <summary>
    /// Registers a target with the registry.  Called automatically from
    /// <see cref="WorldTarget.OnEnable"/>.
    /// </summary>
    /// <param name="target">The target to register.</param>
    public static void Register(WorldTarget target)
    {
        if (target == null)
        {
            return;
        }
        string tag = target.gameObject.tag;
        // Add to the all-targets list
        if (!allTargets.Contains(target))
        {
            allTargets.Add(target);
            TargetRegistered?.Invoke(target);
        }

        // Add to the tag-specific list
        if (!string.IsNullOrWhiteSpace(tag))
        {
            if (!targetsByTag.TryGetValue(tag, out List<WorldTarget> list))
            {
                list = new List<WorldTarget>();
                targetsByTag[tag] = list;
            }
            if (!list.Contains(target))
            {
                list.Add(target);
            }
        }
    }

    /// <summary>
    /// Unregisters a target from the registry.  Called automatically from
    /// <see cref="WorldTarget.OnDisable"/>.
    /// </summary>
    /// <param name="target">The target to unregister.</param>
    public static void Unregister(WorldTarget target)
    {
        if (target == null)
        {
            return;
        }
        string tag = target.gameObject.tag;
        // Remove from the all-targets list
        if (allTargets.Remove(target))
        {
            TargetUnregistered?.Invoke(target);
        }
        // Remove from the tag-specific list
        if (!string.IsNullOrWhiteSpace(tag) && targetsByTag.TryGetValue(tag, out List<WorldTarget> list))
        {
            list.Remove(target);
            // Clean up empty lists to avoid memory bloat
            if (list.Count == 0)
            {
                targetsByTag.Remove(tag);
            }
        }
    }

    /// <summary>
    /// Event invoked when a target is registered.  Subscribers can use this to
    /// update caches when new targets appear.
    /// </summary>
    public static event Action<WorldTarget> TargetRegistered;

    /// <summary>
    /// Event invoked when a target is unregistered.  Subscribers can use this to
    /// update caches when targets disappear.
    /// </summary>
    public static event Action<WorldTarget> TargetUnregistered;

    //// -------------------------------------------------------------------------
    //// Backwards-compatibility properties
    ////
    //// Some existing systems reference WorldTargetRegistry.FoodTargets and
    //// EnemyTargets.  Provide these properties as conveniences that simply
    //// delegate to the generic GetTargetsByTag method.  Food and Enemy are
    //// conventional tags used in the example scenes; developers can define
    //// additional tags as needed.
    ///// <summary>
    ///// Gets all targets tagged as "Food".  This is a convenience for
    ///// compatibility with legacy code.
    ///// </summary>
    //public static IReadOnlyList<WorldTarget> FoodTargets => GetTargetsByTag("Food");

    ///// <summary>
    ///// Gets all targets tagged as "Enemy".  This is a convenience for
    ///// compatibility with legacy code.
    ///// </summary>
    //public static IReadOnlyList<WorldTarget> EnemyTargets => GetTargetsByTag("Enemy");
}