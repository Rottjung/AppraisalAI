using System;
using UnityEngine;

[Serializable]
public sealed class DecisionResult
{
    [SerializeField] private RetrievalCandidate selectedCandidate;

    public RetrievalCandidate SelectedCandidate => selectedCandidate;
    public string PayloadId => selectedCandidate?.Record?.PayloadId;

    public DecisionResult(RetrievalCandidate selectedCandidate)
    {
        this.selectedCandidate = selectedCandidate;
    }

    public override string ToString()
    {
        if (selectedCandidate == null || selectedCandidate.Record == null)
        {
            return "No valid decision";
        }

        return $"{selectedCandidate.Record.PayloadId} (distance {selectedCandidate.Distance:F3})";
    }
}