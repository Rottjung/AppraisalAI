using System.Collections.Generic;
using UnityEngine;
using System.Text;

/// <summary>
/// The Sensors component acts as a container for Signals and orchestrates a list of
/// configurable Sensor modules.  Each Sensor reads some aspect of the world or
/// internal state and writes its output into a Signal.  After updating all
/// sensors, this component forwards the sensor outputs to the DecisionBrain.
/// </summary>
public class Sensors : MonoBehaviour
{
    [SerializeField] private DecisionBrain brain;

    [Header("Signals")]
    [SerializeField] private List<Signal> signals = new();

    [Header("Sensor Modules")]
    [Tooltip("List of sensor configurations. Each sensor writes a value into the signals list.")]
    [SerializeField] private List<Sensor> sensorModules = new();

    [Header("Debug")]
    [SerializeField] private bool logSensors = false;

    private readonly Dictionary<string, int> indexById = new();
    private readonly Dictionary<string, float> valueById = new();

    /// <summary>
    /// Gets the DecisionBrain associated with this Sensors component.
    /// </summary>
    public DecisionBrain Brain => brain;

    /// <summary>
    /// Provides read-only access to the list of signals.
    /// </summary>
    public IReadOnlyList<Signal> Signals => signals;

    public List<Sensor> SensorModules => sensorModules;

    private void Awake()
    {
        RebuildCache();
        // Initialise all sensor modules.  This creates their output signals and
        // populates any caches they require.
        for (int i = 0; i < sensorModules.Count; i++)
        {
            Sensor sensor = sensorModules[i];
            if (sensor != null)
            {
                sensor.Initialize(this, transform);
            }
        }
    }

    private void OnValidate()
    {
        RebuildCache();
        // Initialise sensors in the editor to keep the signal list in sync.
        for (int i = 0; i < sensorModules.Count; i++)
        {
            Sensor sensor = sensorModules[i];
            if (sensor != null)
            {
                sensor.Initialize(this, transform);
            }
        }
    }

    /// <summary>
    /// Rebuilds the internal lookup tables from the current list of signals.
    /// This is called when signals are added or removed in the editor.
    /// </summary>
    [ContextMenu("Rebuild Cache")]
    public void RebuildCache()
    {
        indexById.Clear();
        valueById.Clear();
        for (int i = 0; i < signals.Count; i++)
        {
            Signal signal = signals[i];
            if (string.IsNullOrWhiteSpace(signal.Id))
            {
                continue;
            }
            if (indexById.ContainsKey(signal.Id))
            {
                Debug.LogWarning($"Duplicate Signal id '{signal.Id}' on {name}. Keeping last occurrence.", this);
            }
            indexById[signal.Id] = i;
        }
        for (int i = 0; i < signals.Count; i++)
        {
            Signal signal = signals[i];
            if (string.IsNullOrWhiteSpace(signal.Id))
            {
                continue;
            }
            valueById[signal.Id] = signal.Value;
        }
    }

    /// <summary>
    /// Determines whether a signal with the specified id exists.
    /// </summary>
    public bool HasSignal(string id)
    {
        return !string.IsNullOrWhiteSpace(id) && indexById.ContainsKey(id);
    }

    /// <summary>
    /// Gets the current value of a signal by id.  Returns fallback if the id is
    /// empty or not present.
    /// </summary>
    public float GetValue(string id, float fallback = 0f)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return fallback;
        }
        return valueById.TryGetValue(id, out float value) ? value : fallback;
    }

    /// <summary>
    /// Gets the current value of a signal as an integer.  Returns fallback if the
    /// id is not found.
    /// </summary>
    public int GetInt(string id, int fallback = 0)
    {
        if (!indexById.TryGetValue(id, out int index))
        {
            return fallback;
        }
        return signals[index].GetInt();
    }

    /// <summary>
    /// Gets the current value of a signal as a boolean.  Returns fallback if the
    /// id is not found.
    /// </summary>
    public bool GetBool(string id, bool fallback = false)
    {
        if (!indexById.TryGetValue(id, out int index))
        {
            return fallback;
        }
        return signals[index].GetBool();
    }

    /// <summary>
    /// Attempts to retrieve a signal by id.  Returns true if the id is found.
    /// </summary>
    public bool TryGetSignal(string id, out Signal signal)
    {
        if (!indexById.TryGetValue(id, out int index))
        {
            signal = default;
            return false;
        }
        signal = signals[index];
        return true;
    }

    /// <summary>
    /// Sets the value of a signal.  Returns false if the id is not found.
    /// </summary>
    public bool SetSignal(string id, float value)
    {
        if (!indexById.TryGetValue(id, out int index))
        {
            return false;
        }
        Signal s = signals[index];
        s.SetValue(value);
        signals[index] = s;
        valueById[id] = s.Value;
        return true;
    }

    /// <summary>
    /// Modifies a signal by adding or setting its value.  Returns false if the id
    /// is not found.
    /// </summary>
    public bool ModifySignal(string id, float value, bool additive)
    {
        if (!indexById.TryGetValue(id, out int index))
        {
            return false;
        }
        Signal s = signals[index];
        if (additive)
        {
            s.AddValue(value);
        }
        else
        {
            s.SetValue(value);
        }
        signals[index] = s;
        valueById[id] = s.Value;
        return true;
    }

    /// <summary>
    /// Applies a value to a signal in either additive or absolute mode.
    /// </summary>
    public bool Apply(string id, float value, bool additive = true)
    {
        return ModifySignal(id, value, additive);
    }

    /// <summary>
    /// Applies a delta to the specified signal.  If a configured sensor module
    /// produces this signal and is a state drift sensor, the delta will be
    /// applied to the sensor's internal state and clamped to its configured
    /// range.  Otherwise, the delta will be applied directly to the signal and
    /// clamped between 0 and 1.  This allows external systems to replenish
    /// or drain internal state (e.g., hunger or energy) without directly
    /// manipulating signal values.
    /// </summary>
    /// <param name="id">The signal identifier to modify.</param>
    /// <param name="delta">The amount to add to the signal.  Positive values
    /// increase the value; negative values decrease it.</param>
    public void ApplyToSignal(string id, float delta)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return;
        }
        // Attempt to find a sensor module responsible for this signal.
        foreach (var sensor in sensorModules)
        {
            if (sensor != null && sensor.SignalId == id)
            {
                // Delegate to the sensor.  State drift sensors will
                // clamp based on their min/max range; other sensors ignore this.
                sensor.ApplyStateDelta(delta, this);
                return;
            }
        }
        // No sensor found; modify the raw signal directly and clamp to [0,1].
        if (ModifySignal(id, delta, true))
        {
            float current = GetValue(id);
            SetSignal(id, Mathf.Clamp01(current));
        }
    }

    /// <summary>
    /// Ensures that a signal exists.  If it does not, a new signal is added
    /// with the specified initial value and type.
    /// </summary>
    public bool EnsureSignal(string id, SignalType type, float initialValue = 0f)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return false;
        }
        if (indexById.ContainsKey(id))
        {
            return true;
        }
        Signal signal = new Signal(id, type, initialValue);
        signals.Add(signal);
        int index = signals.Count - 1;
        indexById[id] = index;
        valueById[id] = signal.Value;
        return true;
    }

    /// <summary>
    /// Called each frame to update all sensor modules and push their outputs to
    /// the DecisionBrain.  Sensors should implement any time-dependent logic
    /// inside their Update method.
    /// </summary>
    public void Sense()
    {
        float dt = Time.deltaTime;
        // Update each sensor
        for (int i = 0; i < sensorModules.Count; i++)
        {
            Sensor sensor = sensorModules[i];
            if (sensor != null)
            {
                sensor.Update(this, dt, transform);
            }
        }
        // Push sensor outputs to the brain
        if (brain != null)
        {
            for (int i = 0; i < sensorModules.Count; i++)
            {
                Sensor sensor = sensorModules[i];
                if (sensor == null || string.IsNullOrWhiteSpace(sensor.SignalId))
                {
                    continue;
                }
                float val = GetValue(sensor.SignalId);
                brain.SetInputRaw(sensor.SignalId, val);
            }
        }
        // Debug log
        if (logSensors)
        {
            StringBuilder sb = new StringBuilder();
            bool first = true;
            for (int i = 0; i < sensorModules.Count; i++)
            {
                Sensor sensor = sensorModules[i];
                if (sensor == null || string.IsNullOrWhiteSpace(sensor.SignalId))
                {
                    continue;
                }
                float val = GetValue(sensor.SignalId);
                if (!first) sb.Append(" | ");
                sb.Append($"{sensor.SignalId}={val:F2}");
                first = false;
            }
            if (sb.Length > 0)
            {
                Debug.Log(sb.ToString(), this);
            }
        }
    }
}