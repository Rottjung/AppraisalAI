using UnityEngine;

/// <summary>
/// Represents an object in the world that can be sensed by AI agents.  When
/// enabled, the object registers itself with the <see cref="WorldTargetRegistry"/>,
/// allowing dynamic sensors to efficiently track spawned and despawned targets.
/// Objects are categorised by their Unity tag; sensors use this tag to filter
/// targets.  If no tag filter is specified on a sensor, all registered
/// targets are considered.
/// </summary>
public class WorldTarget : MonoBehaviour
{
    private void OnEnable()
    {
        WorldTargetRegistry.Register(this);
    }

    private void OnDisable()
    {
        WorldTargetRegistry.Unregister(this);
    }
}